from django.shortcuts import render
from django.contrib.auth import login, get_user_model, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse
from accounts.models import MyUser, Agency, Admin, Client
from django.views.generic.list import ListView
from django.urls import reverse_lazy
from django.views.generic.edit import CreateView
from django.db import transaction
from multi_form_view import MultiModelFormView
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
# Create your views here.
from .forms import UserCreationForm, UserLoginForm, AgencyCreationForm, MyUserForm, AgencyForm, AdminCreationForm

User = get_user_model()

def register(request, *args, **kwargs):
    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.user_type = 'client'
        instance.save()
        return HttpResponseRedirect("login")
    context = {
		'form': form
	}

    return render(request, "accounts/register.html", context)


def agencyregister(request, *args, **kwargs):
    form = AgencyCreationForm(request.POST or None)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.user_type = 'agency'
        instance.save()
        return HttpResponseRedirect("login")
    context = {
        'form': form
    }
    return render(request, "accounts/agency.html", context)


def adminregister(request, *args, **kwargs):
    form = AdminCreationForm(request.POST or None)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.user_type = 'admin'
        instance.save()
        return HttpResponseRedirect("login")
    context = {
        'form': form
    }
    return render(request, "accounts/admin.html", context)


def login_view(request, *args, **kwargs):
    form = UserLoginForm(request.POST or None)
    if form.is_valid():
        user_obj = form.cleaned_data.get('user_obj')
       
        login(request, user_obj)
        if user_obj.user_type == 'client':
            return HttpResponseRedirect("/")
    return render(request, "accounts/login.html", {"form": form})


def logout_view(request):
    logout(request)
    return HttpResponseRedirect("/login")

def home(request):
    count = User.objects.count()
    return render(request, 'home.html', {
        'count': count
    })


@login_required
def secret_page(request):
    return render(request, 'secret_page.html')

class SecretPage(LoginRequiredMixin, TemplateView):
    template_name = 'secret_page.html'

# from django.views.generic import CreateView
# class CustomerCreateView(CreateView):
#     form_class = AdminForm #(forms.py)


class AgencyListView(ListView):
    template_name = 'Agency.html'
    model = Agency


class AgencyFormView(MultiModelFormView):
    form_classes = {
        'myuser_form': MyUserForm,
        'agency_form': AgencyForm,
    }
    agency_id = None
    template_name = 'agency_form.html'


    def get_objects(self):
        self.agency_id = self.kwargs.get('agency_id', None)
        try:
            agency = Agency.objects.get(pk=self.agency_id)
        except Agency.DoesNotExist:
            agency = None
        return {
            'agency_form': agency,
            'myuser_form': agency.myuser if agency else None
        }

    def get_success_url(self):
        return reverse('agencys')


    def forms_valid(self, forms):
        myuser = forms['myuser_form'].user_type='agency'
        myuser = forms['myuser_form'].save()
        agency = forms['agency_form'].save(commit=False)
        agency.myuser = myuser
        agency.save()
        return super(AgencyFormView, self).forms_valid(forms)

