from django.conf.urls import url, include
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import TemplateView


from accounts.views import register, agencyregister, adminregister, login_view, logout_view, home, secret_page, AgencyListView, AgencyFormView

urlpatterns = [
    url('admin/', admin.site.urls),
    url('agencyregister/$', agencyregister),
    url('adminregister/$', adminregister),
    url('register/$', register,name='register'),
    url('login/$', login_view, name='login_view'),
    url('logout/$', logout_view),
    url('index', home, name='home'),
    url('secret/', secret_page, name='secret'),
    url('accounts/', include('django.contrib.auth.urls')),

    url('agency/$', AgencyListView.as_view(), name='agencys'),
    url('agency/new/$', AgencyFormView.as_view(), name='agencys_new'),
    # url('agency/edit/(?Pk<agency_id>\d+)$', AgencyFormView.as_view(), name='agencys_edit'),
    # url('multiple/', multiple_forms, name='multiple_forms'),

]
