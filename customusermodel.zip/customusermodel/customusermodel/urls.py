from django.conf.urls import url
from django.contrib import admin

from accounts.views import register, agencyregister, adminregister, login_view, logout_view

urlpatterns = [
    url('admin/', admin.site.urls),
    url('agencyregister/$', agencyregister),
    url('adminregister/$', adminregister),
    url('register/$', register),
    url('login/$', login_view),
    url('logout/$', logout_view)
]
